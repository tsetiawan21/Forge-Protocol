# Forge // Protocol — Android build

This turns the `www/index.html` app into an installable Android APK, using
[Capacitor](https://capacitorjs.com/) to wrap it and a GitHub Actions
workflow to build it — no Android Studio required on your own computer.

Full step-by-step instructions are in the chat message this came with.
Short version:

1. Create a new **public** repo on GitHub (public repos get free Actions
   build minutes).
2. Upload everything in this folder to that repo, keeping the folder
   structure (including the hidden `.github` folder).
3. Go to the repo's **Actions** tab. A build should start automatically —
   if not, click **Build Android APK → Run workflow**.
4. When it finishes (green check, a few minutes), open the run and
   download the **forge-protocol-apk** artifact from the bottom of the
   page. That's a `.zip` containing `app-debug.apk`.
5. Send `app-debug.apk` to your phone (email, Google Drive, USB — any
   way you like), open it there, and allow "install from this source"
   if Android asks. That installs the app.

## If you want to change the app itself later

Edit `www/index.html`, upload the new version to the same repo (it'll
overwrite the old file), and the Actions workflow builds a fresh APK
automatically. Every build is a full replacement — nothing needs
reinstalling by hand except the new APK on your phone.

## Notes

- This builds a **debug** APK, which is why Android calls it an
  "unknown source" — that's normal for an app installed outside the
  Play Store, not a sign anything's wrong.
- Your workout progress is saved in the app's own local storage on
  your phone, same as it works in a browser — it stays put across
  updates as long as you install over the same app (don't uninstall
  it first).
- The `android/` folder isn't committed here — GitHub rebuilds it
  fresh from scratch every run, so it's never stale.
